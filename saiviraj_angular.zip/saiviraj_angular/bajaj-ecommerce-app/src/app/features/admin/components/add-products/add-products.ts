import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-add-products',
  imports: [],
  templateUrl: './add-products.html',
  styleUrl: './add-products.css',
})
export class AddProducts {

}
