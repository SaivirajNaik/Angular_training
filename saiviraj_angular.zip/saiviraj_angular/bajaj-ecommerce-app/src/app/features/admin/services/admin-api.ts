export class AdminApi {
}
