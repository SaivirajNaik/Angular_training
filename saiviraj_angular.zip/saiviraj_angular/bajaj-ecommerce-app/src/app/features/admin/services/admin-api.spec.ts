import { AdminApi } from './admin-api';

describe('AdminApi', () => {
  it('should create an instance', () => {
    expect(new AdminApi()).toBeTruthy();
  });
});
