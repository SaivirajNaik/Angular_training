import { ProductData } from './product';

export class ProductDetailsResponse {
  success: boolean;
  data: ProductData;
}
