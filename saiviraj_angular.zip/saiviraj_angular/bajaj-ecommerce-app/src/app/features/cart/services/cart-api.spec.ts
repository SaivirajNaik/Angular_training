import { CartApi } from './cart-api';

describe('CartApi', () => {
  it('should create an instance', () => {
    expect(new CartApi()).toBeTruthy();
  });
});
