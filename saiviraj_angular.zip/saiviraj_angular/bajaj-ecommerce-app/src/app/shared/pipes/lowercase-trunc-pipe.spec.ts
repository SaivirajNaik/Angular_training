import { LowercaseTruncPipe } from './lowercase-trunc-pipe';

describe('LowercaseTruncPipe', () => {
  it('create an instance', () => {
    const pipe = new LowercaseTruncPipe();
    expect(pipe).toBeTruthy();
  });
});
