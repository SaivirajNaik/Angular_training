import { DateGlobalizationPipe } from './date-globalization-pipe';

describe('DateGlobalizationPipe', () => {
  it('create an instance', () => {
    const pipe = new DateGlobalizationPipe();
    expect(pipe).toBeTruthy();
  });
});
