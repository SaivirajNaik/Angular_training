import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-banner',
  imports: [CommonModule],
  templateUrl: './banner.html',
  styleUrl: './banner.css',
})
export class Banner {}
