import { EmployeeRegistration } from './employee-registration';

describe('EmployeeRegistration', () => {
  it('should create an instance', () => {
    expect(new EmployeeRegistration()).toBeTruthy();
  });
});
