import { EventRegistration } from './event-registration';

describe('EventRegistration', () => {
  it('should create an instance', () => {
    expect(new EventRegistration()).toBeTruthy();
  });
});
