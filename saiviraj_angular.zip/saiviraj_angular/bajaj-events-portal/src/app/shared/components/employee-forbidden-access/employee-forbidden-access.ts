import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-forbidden-access',
  imports: [],
  templateUrl: './employee-forbidden-access.html',
  styleUrl: './employee-forbidden-access.css',
})
export class EmployeeForbiddenAccess {

}
